<?php

session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

require_once "Database.php";

if (isset($_GET["id"])) {

    $enrollmentId = intval($_GET["id"]);
    $userId = $_SESSION["user_id"];

    $database = new Database();
    $conn = $database->connect();

    $stmt = $conn->prepare(
        "DELETE FROM enrollments
         WHERE id = ?
         AND user_id = ?"
    );

    $stmt->bind_param(
        "ii",
        $enrollmentId,
        $userId
    );

    $stmt->execute();

    $stmt->close();
    $conn->close();
}

header("Location: my_schedule.php");
exit();

?>