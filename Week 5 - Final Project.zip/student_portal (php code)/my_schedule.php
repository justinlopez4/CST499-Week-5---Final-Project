<?php

session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

require_once "Database.php";

$database = new Database();
$conn = $database->connect();

$userId = $_SESSION["user_id"];

$stmt = $conn->prepare(
    "SELECT
        e.id AS enrollment_id,
        c.course_code,
        c.course_name,
        c.credits,
        c.semester
     FROM enrollments e
     INNER JOIN courses c
        ON e.course_id = c.id
     WHERE e.user_id = ?
     ORDER BY c.course_code"
);

$stmt->bind_param(
    "i",
    $userId
);

$stmt->execute();

$result = $stmt->get_result();

?>

<!DOCTYPE html>

<html>

<head>
    <title>My Schedule</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

<div class="container wide">

<h1>My Class Schedule</h1>

<table>

<tr>
    <th>Course</th>
    <th>Course Name</th>
    <th>Credits</th>
    <th>Semester</th>
    <th>Action</th>
</tr>

<?php while ($course = $result->fetch_assoc()) { ?>

<tr>

    <td>
        <?php echo htmlspecialchars($course["course_code"]); ?>
    </td>

    <td>
        <?php echo htmlspecialchars($course["course_name"]); ?>
    </td>

    <td>
        <?php echo $course["credits"]; ?>
    </td>

    <td>
        <?php echo htmlspecialchars($course["semester"]); ?>
    </td>

    <td>

        <a href="drop_course.php?id=<?php
            echo $course["enrollment_id"];
        ?>">
            Drop Course
        </a>

    </td>

</tr>

<?php } ?>

</table>

<p>
    <a href="register_classes.php">
        Add More Courses
    </a>
</p>

<p>
    <a href="dashboard.php">
        Back to Dashboard
    </a>
</p>

</div>

</body>
</html>