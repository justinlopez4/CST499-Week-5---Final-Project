<?php

session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

require_once "Database.php";

$database = new Database();
$conn = $database->connect();

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $userId = $_SESSION["user_id"];
    $courseId = intval($_POST["course_id"]);

    $stmt = $conn->prepare(
        "INSERT INTO enrollments
         (user_id, course_id)
         VALUES (?, ?)"
    );

    $stmt->bind_param(
        "ii",
        $userId,
        $courseId
    );

    if ($stmt->execute()) {

        $message = "Course registration successful.";

    } else {

        if ($conn->errno == 1062) {
            $message = "You are already registered for this course.";
        } else {
            $message = "Unable to register for the course.";
        }
    }

    $stmt->close();
}

$result = $conn->query(
    "SELECT id, course_code, course_name, credits, semester
     FROM courses
     ORDER BY course_code"
);

?>

<!DOCTYPE html>

<html>

<head>

    <title>Register for Classes</title>
    <link rel="stylesheet" href="style.css">

</head>

<body>

<div class="container wide">

<h1>Register for Classes</h1>

<?php

if (!empty($message)) {
    echo "<p class='message'>$message</p>";
}

?>

<table>

<tr>
    <th>Course</th>
    <th>Course Name</th>
    <th>Credits</th>
    <th>Semester</th>
    <th>Action</th>
</tr>

<?php while ($course = $result->fetch_assoc()) { ?>

<tr>

    <td>
        <?php echo htmlspecialchars($course["course_code"]); ?>
    </td>

    <td>
        <?php echo htmlspecialchars($course["course_name"]); ?>
    </td>

    <td>
        <?php echo $course["credits"]; ?>
    </td>

    <td>
        <?php echo htmlspecialchars($course["semester"]); ?>
    </td>

    <td>

        <form method="POST">

            <input
                type="hidden"
                name="course_id"
                value="<?php echo $course["id"]; ?>"
            >

            <button type="submit">
                Register
            </button>

        </form>

    </td>

</tr>

<?php } ?>

</table>

<p>
    <a href="dashboard.php">
        Back to Dashboard
    </a>
</p>

</div>

</body>
</html>