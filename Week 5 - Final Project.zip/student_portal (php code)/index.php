<!DOCTYPE html>
<html>
<head>
    <title>Student Portal</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

<div class="container">

    <h1>Student Portal</h1>

    <p>
        Welcome to the Student Portal.
        Students can create an account or log in
        to access enrollment services.
    </p>

    <p>
        <a href="login.php">Login</a>
    </p>

    <p>
        <a href="register.php">Create Account</a>
    </p>

</div>

</body>
</html>