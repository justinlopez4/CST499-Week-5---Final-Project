<?php

require_once "Database.php";

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $fullName = trim($_POST["full_name"]);
    $email = trim($_POST["email"]);
    $username = trim($_POST["username"]);
    $password = $_POST["password"];
    $confirmPassword = $_POST["confirm_password"];

    if (
        empty($fullName) ||
        empty($email) ||
        empty($username) ||
        empty($password)
    ) {
        $message = "Please complete all fields.";
    }

    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Please enter a valid email address.";
    }

    elseif ($password !== $confirmPassword) {
        $message = "Passwords do not match.";
    }

    else {

        $database = new Database();
        $conn = $database->connect();

        // Check for an existing username or email
        $check = $conn->prepare(
            "SELECT id FROM users WHERE email = ? OR username = ?"
        );

        $check->bind_param("ss", $email, $username);
        $check->execute();

        $result = $check->get_result();

        if ($result->num_rows > 0) {

            $message = "That email or username is already registered.";

        } else {

            $hashedPassword = password_hash(
                $password,
                PASSWORD_DEFAULT
            );

            $stmt = $conn->prepare(
                "INSERT INTO users
                (full_name, email, username, password)
                VALUES (?, ?, ?, ?)"
            );

            $stmt->bind_param(
                "ssss",
                $fullName,
                $email,
                $username,
                $hashedPassword
            );

            if ($stmt->execute()) {
                $message = "Registration successful!";
            } else {
                $message = "Registration failed.";
            }

            $stmt->close();
        }

        $check->close();
        $conn->close();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Student Portal Registration</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

<div class="container">

    <h1>Student Portal</h1>

    <h2>Create an Account</h2>

    <?php
    if (!empty($message)) {
        echo "<p class='message'>$message</p>";
    }
    ?>

    <form method="POST" action="">

        <label>Full Name</label>
        <input
            type="text"
            name="full_name"
            required
        >

        <label>Email Address</label>
        <input
            type="email"
            name="email"
            required
        >

        <label>Username</label>
        <input
            type="text"
            name="username"
            required
        >

        <label>Password</label>
        <input
            type="password"
            name="password"
            required
        >

        <label>Confirm Password</label>
        <input
            type="password"
            name="confirm_password"
            required
        >

        <button type="submit">
            Register
        </button>

    </form>

    <p>
        Already have an account?
        <a href="login.php">Login</a>
    </p>

</div>

</body>
</html>