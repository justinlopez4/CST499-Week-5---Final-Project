<?php

session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

?>

<!DOCTYPE html>
<html>

<head>
    <title>Student Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

<div class="container">

    <h1>Student Portal</h1>

    <h2>
        Welcome,
        <?php echo htmlspecialchars($_SESSION["full_name"]); ?>
    </h2>

    <p>
        <a href="register_classes.php">
            Register for Classes
        </a>
    </p>

    <p>
        <a href="my_schedule.php">
            View My Schedule
        </a>
    </p>

    <p>
        <a href="logout.php">
            Logout
        </a>
    </p>

</div>

</body>
</html>